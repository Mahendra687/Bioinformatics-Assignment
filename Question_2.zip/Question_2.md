### Bioinformatics  Assignment for Internship at Elucidata, New Delhi

#### Importing Libraries


```R
#install.packages("BiocManager")
#library("BiocManager")
#library("DESeq2")
#library('tximport')
#library(tidyverse)
#library(ggplot2)
#library(plotly)
#library(biomaRt)
#library(pheatmap)
#library(RColorBrewer)
#library('tibble')
#library(dplyr)
```

**Part 1: Exploratory Data Analysis:** Question 2.1.1


```R
# get countnMatrix dataset
count_matrix = as.matrix(read.csv("count.csv", row.names = "Genes"))
# get normalizedMatrix dataset
norm = as.matrix(read.csv("norm.csv", row.names = "Genes"))
# get meta dataset(sample information:studyDesign)
metaData = as.matrix(read.csv("meta.csv", row.names = "Sample"))

#head(count_matrix) #print the  countnMatrix dataset
#head(norm) #print the normalizedMatrix dataset
#print(metaData) #print the meta datasets

dim(count_matrix)
dim(norm)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>5669</li><li>18</li></ol>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>5669</li><li>18</li></ol>



#### Importing Datasets into DESeq2 


```R
#all(rownames(metaData) %in% colnames(count_matrix))
#all(rownames(metaData) == colnames(count_matrix))
#all(rownames(metaData) %in% colnames(norm))
#all(rownames(metaData) == colnames(norm))

deseq_dataset = DESeqDataSetFromMatrix(countData = count_matrix, colData = metaData, design = ~ Condition)
norm_dataset = as.matrix(norm[ , -1],colData = metaData, design = ~ Condition)
#print(deseq_dataset)
#print(norm_dds)
```

    Warning message in DESeqDataSet(se, design = design, ignoreRank):
    “some variables in design formula are characters, converting to factors”



```R
# set control condition as reference
deseq_dataset$Condition = relevel(deseq_dataset$Condition, ref = "Ctrl")
```


```R
#DESeq does:
#estimatesSizeFactors
#estimatesDispersion
#nbinoWaldtest
deseq_dataset = DESeq(deseq_dataset)
```

    estimating size factors
    
    estimating dispersions
    
    gene-wise dispersion estimates
    
    mean-dispersion relationship
    
    final dispersion estimates
    
    fitting model and testing
    
    -- replacing outliers and refitting for 45 genes
    -- DESeq argument 'minReplicatesForReplace' = 7 
    -- original counts are preserved in counts(dds)
    
    estimating dispersions
    
    fitting model and testing
    



```R
deseq_result = results(deseq_dataset, contrast = c("Condition",
                                                 "Ctrl","Trt"))
summary(deseq_result) #overall result statistics from DESeq2
```

    
    out of 5669 with nonzero total read count
    adjusted p-value < 0.1
    LFC > 0 (up)       : 759, 13%
    LFC < 0 (down)     : 563, 9.9%
    outliers [1]       : 0, 0%
    low counts [2]     : 220, 3.9%
    (mean count < 1)
    [1] see 'cooksCutoff' argument of ?results
    [2] see 'independentFiltering' argument of ?results
    


* So as per DESeq analysis, here in our dataset, we got 5669 genes with non zero read counts with adjusted p-value < 0.1, LFC > 0 for up-reg and LFC < 0 for down-reg and there are 0 outliers based on cooksCutoff distance threshold and there are nearly 220 low count genes with mean count < 1.
* mean with lowest counts start to filter out genes with low expression in the rows because genes of low expression have very low counts numbers(integer values) statistically much likely to be differentially expressed.

* mean counts filter plays a big role to maximize the no of genes that pass the statistical thresholds [up-regulated] if we increase the mean count filter, it will start to filter out genes that are genuinely differentially expressed and that get genes removed from the consideration of S-test which filter out **low counts** rows and left us with few rows out of total rows.


```R
View(deseq_result)
#View(as.data.frame(result_table)
```


    log2 fold change (MLE): Condition Ctrl vs Trt 
    Wald test p-value: Condition Ctrl vs Trt 
    DataFrame with 5669 rows and 6 columns
              baseMean log2FoldChange     lfcSE      stat      pvalue       padj
             <numeric>      <numeric> <numeric> <numeric>   <numeric>  <numeric>
    Gene1      25.8459      -0.239398  0.465205 -0.514607 0.606827578 0.76808240
    Gene2      19.4426       1.852733  0.939797  1.971418 0.048676130 0.15939677
    Gene3     126.8358      -2.011774  0.561396 -3.583523 0.000338991 0.00746396
    Gene4     175.5860      -0.667767  0.557330 -1.198155 0.230856787 0.43094849
    Gene5      34.3060       0.152564  0.548114  0.278343 0.780749161 0.88575935
    ...            ...            ...       ...       ...         ...        ...
    Gene5665   2.51082      -0.770647  0.915464 -0.841810 0.399894282 0.60077859
    Gene5666   3.49467      -0.164902  0.732327 -0.225175 0.821843234 0.90633956
    Gene5667  10.72750      -2.096947  0.568256 -3.690143 0.000224128 0.00577944
    Gene5668   4.43024       1.278750  0.694185  1.842089 0.065462156 0.19229288
    Gene5669  81.80253       0.435672  0.528016  0.825111 0.409308608 0.60871250


**In this results table:**

Each of these columns tells something about the expression of the gene in each given row:
* **baseMeans:** average normalized counts for the gene across all the samples in the columns(experiment), a gene with baseMEan 0 and less than the threshold is filtered out for all the tests.

* **fold change:** that's the difference between two conditions in our differential gene expression test expressed as a log2 ratio.
for example, if FC is 2 means upregulation is 1 if FC is 4 then the upreg is 2, FC is 8  upreg is 3 and so on.. and same as for -ve FC -2 FC means the upregulation goes down towards the zero.
* **lfcSE:** gives us the idea that how robust the change is so larger the lfcSE is less robust the FC observation is

* **stat:** is the result of the wald test, a test of binomial distribution which uses the mean(basemean) and the dispersion which we estimated when we run the estimate dispersion to see the differences between two conditions and that test-statistics is used to convert into the p-value to see the significant differences. 

The p-values are represented in two ways:

**p-value:** which is the output of raw p-value means is this gene differentially expressed may or may not and 
**padj:** this is a p-value adjusted for multiple hypo-test and this is essential for this kind of analysis because we are applying statistical tests on thousands of or beyond datasets points in one go, so these are the linked hypothesis, therefore, it's very important to we take counts of p-values less than < 0.05 it is sufficient to reject null hypo.
so when we consider which genes are differentially expressed it is the padj columns values that we consider for the analysis.

**Heat-Map:** Question 2.1.2


```R
vst = varianceStabilizingTransformation(count_matrix)
data_for_hm = as.matrix.default(vst[1:110, 1:18])

greys = colorRampPalette(brewer.pal(9, "Greys"))(100)
pairs = colorRampPalette(brewer.pal(12, "Paired"))(100)
last_scheme = colorRampPalette(brewer.pal(7, "Blues"))(100)

pheatmap(data_for_hm, fontsize_row=4, scale='row',
         color=last_scheme, cutree_cols = 2,
         cutree_rows = 2)
```


![png](output_14_0.png)


* So this is a HeatMap of those differentially expressed genes which looks quite nice as you can see the sample on right clearly up-regulated expression is higher than the sample on the left, and block of the bottom down-regulated genes expression level higher in the right and low on the left side.

* The way we normally think about heatmap is having columns and rows exactly the same as the matrix
* heatmap colours these cells according to the expressions of that gene in particular samples
* heatmap also applied clustering over the top of it, and so we end with a dendrogram linking the samples together as well as genes together which have different clusters of genes.

**PCA-Plot:** Question 2.1.3


```R
vst = varianceStabilizingTransformation(deseq_dataset)
plotPCA(vst, intgroup=c("Condition"))+
  theme_bw()
```


![png](output_17_0.png)


* Before perfoming PCA we need to transform count datasets using varianceStabilizingTransformation which gives us the right shape for PCA in order to produce a representation of dataset which is meanable for PCA.

* The main thing in PCA is to use for bioinformatician is that the closer the two-point is on this plot the most they similar to one another. and this PCA represents the amount of variance in dataest which explains the proportion of the variance in the data. where the PC1 exlains 53% of the variance in the whole dataset. [DESeq2 PCAplot only uses the top 500 most defferentially expressed genes] and PC2 which represents 10% variance and we see on the X-axis, we see that the variance due to drug that in this plot affecting the gene expression  and on the other hand control sample group: a bit more variable than affecting sample group and kind of widespread on the PCA so both of this sample behave differently quite 
nicely. if they most spread on the x-axis or y-axis we can say larger anmout of variations. 


Question 2.1.4


```R
plot1 = plotDispEsts(deseq_dataset)
```


![png](output_20_0.png)


* This calculates the gene-wise dispersion estimates for the datasets and applies the shrinkage and gives us final dispersion estimates
* Normal relationship on RNASeq data: So here mean and variance in RNAseq data are not independent of one another so the variance is not continuous with mean of count data, as mean count from left to right increases and variance goes down.
* Worth noting here is, that the black point is the gene-wise estimates of dispersion so that fresh genes from the total observation dispersion have been estimated.
* So mean dispersion with the mean and average dispersion with average counts fitted through the red line and black point shrunk towards the red fitted line [dispersion estimates] so the resulting dispersion estimates gene-wise are than the blue points.
* There are two groups of blue points, one is scattered around the red line and the second scattered around the black point away and from the fitted first blue points, these are actually genes which are considered as outliers in terms of dispersion.


#### Retrive and filter results
**Criteria to filter datasets:**
* padj < 0.05
* log2FoldChange > 1 < -1



```R
result_df = as.data.frame(deseq_result) #DESeq dataframe to R-base Dataframe
head(result_df) # result_table is a DataFrame not a data.frame: a base-r dataframe
```


<table class="dataframe">
<caption>A data.frame: 6 × 6</caption>
<thead>
	<tr><th></th><th scope=col>baseMean</th><th scope=col>log2FoldChange</th><th scope=col>lfcSE</th><th scope=col>stat</th><th scope=col>pvalue</th><th scope=col>padj</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Gene1</th><td> 25.84594</td><td>-0.2393976</td><td>0.4652047</td><td>-0.5146071</td><td>0.6068275784</td><td>0.768082399</td></tr>
	<tr><th scope=row>Gene2</th><td> 19.44258</td><td> 1.8527331</td><td>0.9397974</td><td> 1.9714176</td><td>0.0486761297</td><td>0.159396773</td></tr>
	<tr><th scope=row>Gene3</th><td>126.83579</td><td>-2.0117739</td><td>0.5613956</td><td>-3.5835231</td><td>0.0003389907</td><td>0.007463961</td></tr>
	<tr><th scope=row>Gene4</th><td>175.58604</td><td>-0.6677671</td><td>0.5573296</td><td>-1.1981547</td><td>0.2308567869</td><td>0.430948486</td></tr>
	<tr><th scope=row>Gene5</th><td> 34.30602</td><td> 0.1525636</td><td>0.5481139</td><td> 0.2783429</td><td>0.7807491609</td><td>0.885759354</td></tr>
	<tr><th scope=row>Gene6</th><td> 15.82625</td><td>-0.7964497</td><td>0.6016753</td><td>-1.3237203</td><td>0.1855959644</td><td>0.377114418</td></tr>
</tbody>
</table>




```R
plotCounts(deseq_dataset, gene='Gene1',
           intgroup='Condition')
```


![png](output_24_0.png)


As per plotCounts graph Ctrl and Trt having higher outlier can be filtered out by applying cooksCutoff distance.

**Part 2: Differential Expression (DE):** Question 2.2.1


**Three steps to DESeq2 analysis:** which will give us all of the genes which pass all the filters.
* estimate size factors (normalisation)
* estimate dispersions
* apply statistics (Wald Test)



```R
#complete.cases(result_df)
#sum(complete.cases(result_df))
filter_df1 = result_df[complete.cases(result_df),]
#View(filter_df1) 
dim(filter_df1)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>5449</li><li>6</li></ol>



So here in our datasets out of [5669/. from result statistics DESeq2] nearly 5449 data points are true which pass the all the DESeq2 filtters.
* True: for represent the observation 
* False: represent the NA


```R
#filter_df1$padj < 0.05
filter_df2 = filter_df1[filter_df1$padj < 0.05,]
#View(filter_df2)
dim(filter_df1)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>5449</li><li>6</li></ol>



* if the p-vlues condition meet all values will be TURE
* if not all values will be FASLE
* **Calculation** by looking at result table from DESeq2:
5669 - 220 - 0 = 5449


```R
#abs(filter_df2$log2FoldChange) > 1
filter_df3 = filter_df2[abs(filter_df2$log2FoldChange) > 0.25,]  #filter with abs value 
#View(filter_df3)
dim(filter_df3)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>834</li><li>6</li></ol>



So in total **834** genes which pass all of the filter criteria

**Plotting** 

**MA-Plot:** Question 2.2.2


```R
plotMA(deseq_result, ylim=c(-2,2), main = "MA-plot", colNonSig = "red")
```


![png](output_35_0.png)


* MA-plot aims to represent the comparison of mean(x-axis) normalized counts[baseMean] and FoldChange (y-axis) from the result table which illustrate a few things

* The high level of variance presence of low count genes with low counts tend to have quite high fold changes but they don't tend to be significantly differentially expressed. Anything colour in red is just an adjusted p-value lower than 0.01 which is not been used to define DE-genes. 
* So here those genes with low expression tend to have to be more spread away from the Zero line [log-fold change] they tend to be significant, and genes with low counts don't tend to be robustly differently expressed and higher mean counts tend to be more likely to DE-genes

**volcano plot**


```R
filter_df1$test = filter_df1$padj < 0.05 & abs(filter_df1$log2FoldChange) > 1 #combine test
ggplot(filter_df1, aes(x=log2FoldChange, y = -log10(padj))) +
geom_point(aes(colour = test ), size=1, alpha=0.3 )+
scale_colour_manual(values=c('black', 'red')) +
geom_vline(xintercept = 1, colour="blue", linetype=2) +
geom_vline(xintercept = -1, colour="blue", linetype=2) +
geom_hline(yintercept = -log10(0.05),colour="green",  linetype=2) +
#theme(legend.position = "none")
#xlim(-3,3)+
#ylim(0,10)+
#ggplotly(g)
theme_bw()
```


![png](output_38_0.png)


**Genes Annoted Volcano Plot**


```R
#filter_df1$test = filter_df1$padj < 0.05 & abs(filter_df1$log2FoldChange) > 1 #combine test
#filter_df1 = rownames_to_column(filter_df1, var = 'ensgene')
#g = ggplot(filter_df1, aes(x=log2FoldChange, y = -log10(padj),name = ensgene')) +
#geom_point(aes(colour = test ), size=1, alpha=0.3)+
#scale_colour_manual(values=c('black', 'red'))+
#geom_vline(xintercept = 1, colour="green", linetype=3)+
#geom_vline(xintercept = -1, colour="green", linetype=2)+
#geom_hline(yintercept = -log10(0.05),colour="blue",  linetype=2)+
#theme(legend.position = "none")
#xlim(-3,3)+
#ylim(0,10)+
#theme_bw()
#ggplotly(g)
```

* Somehow similar to the MA plot
* On the log2-fold change on the x-axis, so the idea is how many genes change on the axis, so here we can see Up and Down-regulated genes
* On the y-axis idea is how significant that change is, it represents the adjusted p-value but in order that more significant genes come up higher on the y-axis, so here we log transform it, so actually the way normally represented is like the -log10 of the p-value and the reason for that is because p-values lie between 0 and 1. so here more significant p-value is when smaller the p-value is than higher the -log10 p-value is.
* Point with a low fold change tend to also have a small p-value
* Fold change increases at the same time p-value also tend to increases

**Annotation with biomaRt**


```R
#install.packages('biomaRt')
#library('biomaRt')
#??biomaRt
#??DESeq2
#listMarts()

#ensembl106 = useEnsembl(biomart ="ensembl", version = 106) #datasets
#View(listDatasets(ensembl106))

#ensembl106 = useDataset("hsapiens_gene_ensembl", mart = ensembl106 ) #dataselection
#View(listAttributes(ensembl106))
#View(listFilters(ensembl106))

#getBM(attributes = c("ensembl_gene_id",
                     #"ensembl_gene_id_version",
                     #"ensembl_transcript_id",
                    #"ensembl_transcript_id_version",
                    #"external_gene_name"), filters = c('ensembl_gene_id'), 
      #values = filter_df1,
      #mart = ensembl106)

#annotation = getBM(attributes=('ensembl_gene_id'), #combine annotation with RNASeq dataset
                   #filters = ('ensembl_gene_id'),
                   #values = filter_df1$ensgene,
                   #mart = ensembl106)
#View(annotation)
#View(filter_df1)

#annotated_df = left_join(filter_df1, annotation,
                         #by=c('ensgene'='ensembl_gene_id'))
#View(annotated_df)
```


```R
write.csv(as.data.frame(filter_df3), file="condition_ctrl_vs_trt_dge.csv")
```

Question 2.2.3


```R


highest_top = c("Gene7","Gene13","Gene30","Gene35","Gene45","Gene46","Gene47","Gene54","Gene57","Gene73")
lowest_top = c("Gene3","Gene24","Gene26","Gene43","Gene51","Gene80","Gene81","Gene86","Gene93","Gene100")

top_genes = data.frame(highest_top, lowest_top)
top_genes
```


<table class="dataframe">
<caption>A data.frame: 10 × 2</caption>
<thead>
	<tr><th scope=col>highest_top</th><th scope=col>lowest_top</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>Gene7 </td><td>Gene3  </td></tr>
	<tr><td>Gene13</td><td>Gene24 </td></tr>
	<tr><td>Gene30</td><td>Gene26 </td></tr>
	<tr><td>Gene35</td><td>Gene43 </td></tr>
	<tr><td>Gene45</td><td>Gene51 </td></tr>
	<tr><td>Gene46</td><td>Gene80 </td></tr>
	<tr><td>Gene47</td><td>Gene81 </td></tr>
	<tr><td>Gene54</td><td>Gene86 </td></tr>
	<tr><td>Gene57</td><td>Gene93 </td></tr>
	<tr><td>Gene73</td><td>Gene100</td></tr>
</tbody>
</table>



**Part 3** Question 2.3.1: these genes are less likely to be up/down regulated based on log2FC/lookup table

#### References

[Reference1](http://bioconductor.org/packages/devel/bioc/vignettes/DESeq2/inst/doc/DESeq2.html) | 
[Reference2](https://github.com/Mahendra687/lockdown-learning/tree/master/covid-rnaseq) |
[Reference3](https://sbc.shef.ac.uk/workshops/2019-01-14-rna-seq-r/rna-seq-annotation-visualisation.nb.html)

### Thank you,
![DEgene.png](attachment:DEgene.png)

 Regards: Mahendra Singh
